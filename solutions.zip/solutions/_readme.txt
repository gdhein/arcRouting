Instances available in TSPLIB have their vertices numbered, and the depot is numbered as 1.
The solutions presented use the same notation, so the depot is also presented as number 1.

Each file contains all nondominated solutions of a approximation set, and for each solution we present both objectives (dispersion and profit) and the routes.

Notice also that there are 20 different nondominated sets for the same instance, one for each execution.
MOGLS frontiers are in files 0 to 9, while MOGA fronntiers are in files 10 to 19.